**********Softgrid test backend******

1. Go to the folder and run "npm install" command 
2. After installing packages run "npm start" command
3. Visit to "localhost:3000" in a browser

**********Softgrid test frontend******

1. Go to the "public/softgrid-frontend" folder and run "npm install" command 
2. After installing packages run "ng serve" command